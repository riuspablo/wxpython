#! /usr/bin/env python
# -*- coding: utf-8 -*-

#	paquete.modulo
import modulo.suma
#	paquete.modulo.funcion
print modulo.suma.suma(2,3)
