#! /usr/bin/env python
# -*- coding: utf-8 -*-


def suma(a,b):
	return a + b
